print("CALCULATOR")
num1=int(input("Enter number 1:"))
num2=int(input("Enter number 2:"))
add = num1 + num2
print("Addition of num1 and num2:",add)
diff = num1 - num2
print("Difference between num1 and num2:",diff)
prod = num1 * num2
print("Product of num1 and num2:",prod)
div = num1 / num2
print("Addition of num1 and num2:",div)
