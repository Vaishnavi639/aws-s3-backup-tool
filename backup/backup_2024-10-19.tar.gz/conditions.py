dow = input("ENTER DAY OF WEEK: ").lower()
print("Day of week: ",dow)
if dow == "saturday" or dow == "sunday":
    print("I will practice DevOps")
else:
    print("I will attend college")