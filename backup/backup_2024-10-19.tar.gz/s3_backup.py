"""
This is a script to take backup from local to AWS S3
boto3 --> used to do AWS tasks using Python

"""

import boto3
s3 = boto3.resource("s3")
def show_buckets(s3):
    print(s3.buckets.all())
show_buckets(s3)
